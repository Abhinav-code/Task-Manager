const mongoose=require('mongoose')
const validator= require('validator')
mongoose.connect('mongodb://127.0.0.1:27017/task-manager-api',{
    useNewUrlParser:true,
    useCreateIndex:true
}) 

// const User=mongoose.model('Users',{
//       name:{
//           type:String,
//           required:true,
//           trim:true
//            },
//       age:{
//           type:Number,
//           default:0,
//           validate(value){
//               if(value<0){
//                   throw  new Error('age can never be negative')
//               }

//           }
          
//           },
//       email:{
//          type:String,
//          required:true,
//          trim:true,
//          lowercase:true,
//          validate(value){
//               if(!validator.isEmail(value)){
//                   throw new Error('Email is invalid')
//               }
//          }
//       },
//       password:{
//          type:String,
//          trim:true,
//          required:true,
//          minlength:7,
//          validate(value){
//              if(value.toLowerCase().includes('password')){
//                  throw new Error('not use password')
//              }
//          }


//       }

// })

// const me = new User({
//     name:'mikey',
//     age:24,
//     email:'ThisisMike672@gmail.com',
//     password:'pas123word'
// })
// me.save().then(()=>{
//     console.log(me)
// }).catch((error)=>{
//     console.log(error);
//     })

const Task=mongoose.model('Tasks',{
    description:{
        type:String,
        required:true,
        trim:true
    },
    completed:{
        type:Boolean,
        default:false
    }
})
 const me=new Task({
     description:'              learn the mongoose library with npm',
     completed:true
 })

me.save().then(()=>{
    console.log(me)
}).catch((error)=>{
   console.log(error)
})